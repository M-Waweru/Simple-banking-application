/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mathe
 */
package bank;

import java.util.Scanner;

public class Main {

    //class variable
    public static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        new Login().setVisible(true);
    }
}
